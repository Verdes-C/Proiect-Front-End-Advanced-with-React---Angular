function LandingPage() {
  return <p>Landing Page</p>;
}
export default LandingPage;
